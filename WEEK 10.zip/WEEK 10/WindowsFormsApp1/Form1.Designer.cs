﻿namespace WindowsFormsApp1
{
    partial class Player
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_kiri = new System.Windows.Forms.Button();
            this.bt_back = new System.Windows.Forms.Button();
            this.bt_next = new System.Windows.Forms.Button();
            this.bt_kanan = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_id = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_name = new System.Windows.Forms.TextBox();
            this.dtp_date = new System.Windows.Forms.DateTimePicker();
            this.tb_national = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.num = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.bt_save = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.num)).BeginInit();
            this.SuspendLayout();
            // 
            // bt_kiri
            // 
            this.bt_kiri.Location = new System.Drawing.Point(120, 54);
            this.bt_kiri.Name = "bt_kiri";
            this.bt_kiri.Size = new System.Drawing.Size(101, 96);
            this.bt_kiri.TabIndex = 0;
            this.bt_kiri.Text = "<<";
            this.bt_kiri.UseVisualStyleBackColor = true;
            this.bt_kiri.Click += new System.EventHandler(this.bt_kiri_Click);
            // 
            // bt_back
            // 
            this.bt_back.Location = new System.Drawing.Point(228, 54);
            this.bt_back.Name = "bt_back";
            this.bt_back.Size = new System.Drawing.Size(101, 96);
            this.bt_back.TabIndex = 1;
            this.bt_back.Text = "<";
            this.bt_back.UseVisualStyleBackColor = true;
            this.bt_back.Click += new System.EventHandler(this.bt_back_Click);
            // 
            // bt_next
            // 
            this.bt_next.Location = new System.Drawing.Point(335, 54);
            this.bt_next.Name = "bt_next";
            this.bt_next.Size = new System.Drawing.Size(101, 96);
            this.bt_next.TabIndex = 2;
            this.bt_next.Text = ">";
            this.bt_next.UseVisualStyleBackColor = true;
            this.bt_next.Click += new System.EventHandler(this.bt_next_Click);
            // 
            // bt_kanan
            // 
            this.bt_kanan.Location = new System.Drawing.Point(442, 54);
            this.bt_kanan.Name = "bt_kanan";
            this.bt_kanan.Size = new System.Drawing.Size(101, 96);
            this.bt_kanan.TabIndex = 3;
            this.bt_kanan.Text = ">>";
            this.bt_kanan.UseVisualStyleBackColor = true;
            this.bt_kanan.Click += new System.EventHandler(this.bt_kanan_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(151, 170);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 25);
            this.label1.TabIndex = 4;
            this.label1.Text = "Player ID";
            // 
            // tb_id
            // 
            this.tb_id.Location = new System.Drawing.Point(282, 170);
            this.tb_id.Name = "tb_id";
            this.tb_id.Size = new System.Drawing.Size(189, 31);
            this.tb_id.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(115, 220);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(135, 25);
            this.label2.TabIndex = 6;
            this.label2.Text = "Player Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(152, 268);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 25);
            this.label3.TabIndex = 7;
            this.label3.Text = "Birthdate";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(137, 321);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 25);
            this.label4.TabIndex = 8;
            this.label4.Text = "Nationality";
            // 
            // tb_name
            // 
            this.tb_name.Location = new System.Drawing.Point(282, 220);
            this.tb_name.Name = "tb_name";
            this.tb_name.Size = new System.Drawing.Size(181, 31);
            this.tb_name.TabIndex = 9;
            // 
            // dtp_date
            // 
            this.dtp_date.Location = new System.Drawing.Point(282, 268);
            this.dtp_date.Name = "dtp_date";
            this.dtp_date.Size = new System.Drawing.Size(377, 31);
            this.dtp_date.TabIndex = 10;
            // 
            // tb_national
            // 
            this.tb_national.Location = new System.Drawing.Point(282, 315);
            this.tb_national.Name = "tb_national";
            this.tb_national.Size = new System.Drawing.Size(181, 31);
            this.tb_national.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(184, 366);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 25);
            this.label5.TabIndex = 12;
            this.label5.Text = "Team";
            // 
            // cb_team
            // 
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Location = new System.Drawing.Point(282, 363);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(181, 33);
            this.cb_team.TabIndex = 13;
            // 
            // num
            // 
            this.num.Location = new System.Drawing.Point(282, 421);
            this.num.Name = "num";
            this.num.Size = new System.Drawing.Size(181, 31);
            this.num.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(103, 423);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(147, 25);
            this.label6.TabIndex = 15;
            this.label6.Text = "Team Number";
            // 
            // bt_save
            // 
            this.bt_save.Location = new System.Drawing.Point(282, 471);
            this.bt_save.Name = "bt_save";
            this.bt_save.Size = new System.Drawing.Size(131, 50);
            this.bt_save.TabIndex = 16;
            this.bt_save.Text = "Save";
            this.bt_save.UseVisualStyleBackColor = true;
            // 
            // Player
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(764, 554);
            this.Controls.Add(this.bt_save);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.num);
            this.Controls.Add(this.cb_team);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tb_national);
            this.Controls.Add(this.dtp_date);
            this.Controls.Add(this.tb_name);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tb_id);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bt_kanan);
            this.Controls.Add(this.bt_next);
            this.Controls.Add(this.bt_back);
            this.Controls.Add(this.bt_kiri);
            this.Name = "Player";
            this.Text = "Player";
            this.Load += new System.EventHandler(this.Player_Load);
            ((System.ComponentModel.ISupportInitialize)(this.num)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_kiri;
        private System.Windows.Forms.Button bt_back;
        private System.Windows.Forms.Button bt_next;
        private System.Windows.Forms.Button bt_kanan;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_id;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_name;
        private System.Windows.Forms.DateTimePicker dtp_date;
        private System.Windows.Forms.TextBox tb_national;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cb_team;
        private System.Windows.Forms.NumericUpDown num;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button bt_save;
    }
}

