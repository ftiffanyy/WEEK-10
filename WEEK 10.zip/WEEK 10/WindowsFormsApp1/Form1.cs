﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{
    public partial class Player : Form
    {
        public Player()
        {
            InitializeComponent();
        }
        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        DataTable dtplayer;
        DataTable dtteam;
        DataTable dtnationality;
        int index = 0;

        private void Player_Load(object sender, EventArgs e)
        {
            sqlConnect = new MySqlConnection("server = 192.168.88.201;" + "uid = student;" + "pwd=isbmantap;" + "database=premier_league");
            sqlConnect.Open();
            sqlConnect.Close();

            dtplayer = new DataTable();
            dtteam = new DataTable();
            dtnationality = new DataTable();

            string query = "select * from player";
            sqlCommand = new MySqlCommand(query, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtplayer);
            string query2 = "select * from team";
            sqlCommand = new MySqlCommand(query2, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtteam);
            string query3 = "select * from nationality";
            sqlCommand = new MySqlCommand(query3, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtnationality);
            tb_id.Text = dtplayer.Rows[0][0].ToString();
            tb_name.Text = dtplayer.Rows[0][2].ToString();
            dtp_date.Value = Convert.ToDateTime(dtplayer.Rows[0][7]);
            int nationality = 0;
            for (int i = 0; i < dtnationality.Rows.Count; i++)
            {
                if (dtnationality.Rows[i][0].ToString() == dtplayer.Rows[0][3].ToString())
                {
                    nationality = i; break;
                }
            }
            tb_national.Text = dtnationality.Rows[nationality][2].ToString();
            int team = 0;
            for (int i = 0; i < dtteam.Rows.Count; i++)
            {
                if (dtteam.Rows[i][0].ToString() == dtplayer.Rows[0][1].ToString())
                {
                    team = i; break;
                }
            }
            cb_team.DataSource = dtteam;
            cb_team.DisplayMember = "team_name";
            cb_team.SelectedIndex = team;
            num.Value = Convert.ToInt32(dtplayer.Rows[0][1]);
        }

        private void bt_next_Click(object sender, EventArgs e)
        {
            if(index == dtplayer.Rows.Count)
            {
                
            }
            else if (index != dtplayer.Rows.Count)
            {
                index++;
            }
            tb_id.Text = dtplayer.Rows[index][0].ToString();
            tb_name.Text = dtplayer.Rows[index][2].ToString();
            dtp_date.Value = Convert.ToDateTime(dtplayer.Rows[index][7]);
            int nationality = 0;
            for (int i = 0; i < dtnationality.Rows.Count; i++)
            {
                if (dtnationality.Rows[i][0].ToString() == dtplayer.Rows[index][3].ToString())
                {
                    nationality = i; break;
                }
            }
            tb_national.Text = dtnationality.Rows[nationality][2].ToString();
            int team = 0;
            for (int i = 0; i < dtteam.Rows.Count; i++)
            {
                if (dtteam.Rows[i][0].ToString() == dtplayer.Rows[index][1].ToString())
                {
                    team = i; break;
                }
            }
            cb_team.DataSource = dtteam;
            cb_team.DisplayMember = "team_name";
            cb_team.SelectedIndex = team;
            num.Value = Convert.ToInt32(dtplayer.Rows[index][1]);
        }

        private void bt_kanan_Click(object sender, EventArgs e)
        {
            index = dtplayer.Rows.Count - 1;
            tb_id.Text = dtplayer.Rows[index][0].ToString();
            tb_name.Text = dtplayer.Rows[index][2].ToString();
            dtp_date.Value = Convert.ToDateTime(dtplayer.Rows[index][7]);
            int nationality = 0;
            for (int i = 0; i < dtnationality.Rows.Count; i++)
            {
                if (dtnationality.Rows[i][0].ToString() == dtplayer.Rows[index][3].ToString())
                {
                    nationality = i; break;
                }
            }
            tb_national.Text = dtnationality.Rows[nationality][2].ToString();
            int team = 0;
            for (int i = 0; i < dtteam.Rows.Count; i++)
            {
                if (dtteam.Rows[i][0].ToString() == dtplayer.Rows[index][1].ToString())
                {
                    team = i; break;
                }
            }
            cb_team.DataSource = dtteam;
            cb_team.DisplayMember = "team_name";
            cb_team.SelectedIndex = team;
            num.Value = Convert.ToInt32(dtplayer.Rows[index][1]);
        }

        private void bt_back_Click(object sender, EventArgs e)
        {
            if(index == 0)
            {

            }
            else if (index != 0)
            {
                index--;
            }
            tb_id.Text = dtplayer.Rows[index][0].ToString();
            tb_name.Text = dtplayer.Rows[index][2].ToString();
            dtp_date.Value = Convert.ToDateTime(dtplayer.Rows[index][7]);
            int nationality = 0;
            for (int i = 0; i < dtnationality.Rows.Count; i++)
            {
                if (dtnationality.Rows[i][0].ToString() == dtplayer.Rows[index][3].ToString())
                {
                    nationality = i; break;
                }
            }
            tb_national.Text = dtnationality.Rows[nationality][2].ToString();
            int team = 0;
            for (int i = 0; i < dtteam.Rows.Count; i++)
            {
                if (dtteam.Rows[i][0].ToString() == dtplayer.Rows[index][1].ToString())
                {
                    team = i; break;
                }
            }
            cb_team.DataSource = dtteam;
            cb_team.DisplayMember = "team_name";
            cb_team.SelectedIndex = team;
            num.Value = Convert.ToInt32(dtplayer.Rows[index][1]);
        }

        private void bt_kiri_Click(object sender, EventArgs e)
        {
            index = 0;
            tb_id.Text = dtplayer.Rows[0][0].ToString();
            tb_name.Text = dtplayer.Rows[0][2].ToString();
            dtp_date.Value = Convert.ToDateTime(dtplayer.Rows[0][7]);
            int nationality = 0;
            for (int i = 0; i < dtnationality.Rows.Count; i++)
            {
                if (dtnationality.Rows[i][0].ToString() == dtplayer.Rows[0][3].ToString())
                {
                    nationality = i; break;
                }
            }
            tb_national.Text = dtnationality.Rows[nationality][2].ToString();
            int team = 0;
            for (int i = 0; i < dtteam.Rows.Count; i++)
            {
                if (dtteam.Rows[i][0].ToString() == dtplayer.Rows[0][1].ToString())
                {
                    team = i; break;
                }
            }
            cb_team.DataSource = dtteam;
            cb_team.DisplayMember = "team_name";
            cb_team.SelectedIndex = team;
            num.Value = Convert.ToInt32(dtplayer.Rows[0][1]);
        }
    }
}
